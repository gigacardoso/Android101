/** Automatically generated file. DO NOT MODIFY */
package edu.vanderbilt.mooc.mooc_cp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}